import boto3
import json


def create_s3_bucket():
    s3 = boto3.client('s3')
    bucket_name = "trapforment"

    # Check if the bucket already exists
    existing_buckets = s3.list_buckets()
    if any(bucket['Name'] == bucket_name for bucket in existing_buckets['Buckets']):
        print(f'Bucket "{bucket_name}" already exists.')
    else:
        s3.create_bucket(Bucket=bucket_name)
        print(f'Bucket "{bucket_name}" created.')
        
def create_login_entries():
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('login')

    # Replace with your RMIT student ID
    student_id = "s3759757"

    for i in range(10):
        email = f"{student_id}{i}@student.rmit.edu.au"
        user_name = f"QuangMinhDuong{i}"
        password = str(i).zfill(5) + str((i + 1) % 10)

        table.put_item(Item={'email': email, 'user_name': user_name, 'password': password})

def create_music_table():
    dynamodb = boto3.resource('dynamodb')
    table_name = 'music'

    # Create the music table
    dynamodb.create_table(
        TableName=table_name,
        KeySchema=[
            {'AttributeName': 'title', 'KeyType': 'HASH'},
            {'AttributeName': 'artist', 'KeyType': 'RANGE'}
        ],
        AttributeDefinitions=[
            {'AttributeName': 'title', 'AttributeType': 'S'},
            {'AttributeName': 'artist', 'AttributeType': 'S'}
        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 5,
            'WriteCapacityUnits': 5
        }
    )

def load_music_data():
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('music')

    # Load the JSON data from a1.json
    with open('a1.json', 'r') as f:
        data = json.load(f)

    # Insert the data into the DynamoDB music table
    for entry in data:
        table.put_item(Item=entry)

def download_images_and_upload_to_s3():
    import requests
    from io import BytesIO

    s3 = boto3.client('s3')
    bucket_name = "trapforment"  # Replace with your S3 bucket name

    # Load the JSON data from a1.json
    with open('a1.json', 'r') as f:
        data = json.load(f)
        images = [song['img_url'] for song in data['songs']]

    for image_url in images:
        response = requests.get(image_url)
        file_object = BytesIO(response.content)
        filename = image_url.split('/')[-1]

        # Upload the image to S3 and make it public
        s3.put_object(
            Bucket=bucket_name,
            Key=filename,
            Body=file_object,
            ContentType='image/jpeg',
            ACL='public-read'  # This makes the uploaded image public
        )


def lambda_handler(event, context):
    create_s3_bucket()
    create_login_entries()
    create_music_table()
    load_music_data()
    download_images_and_upload_to_s3()

    return {
        'statusCode': 200,
        'body': json.dumps('DynamoDB and S3 setup completed.')
    }
